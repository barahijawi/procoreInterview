package com.example.procoreinterview.domain

data class PockemonCard(
    val id: String,
    val name:String,
    val hp:String,
    val imageUrl: String
)
