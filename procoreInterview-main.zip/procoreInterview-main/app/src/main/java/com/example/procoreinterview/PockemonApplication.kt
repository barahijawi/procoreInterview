package com.example.procoreinterview

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PockemonApplication : Application()
{
}